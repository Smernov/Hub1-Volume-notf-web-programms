from flask import Flask, render_template, request, jsonify
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
from comtypes import CLSCTX_ALL, CoInitialize, CoUninitialize
from win10toast import ToastNotifier
import psutil
import webbrowser

app = Flask(__name__)
toaster = ToastNotifier()

def get_volume():
    CoInitialize()
    try:
        devices = AudioUtilities.GetSpeakers()
        interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        volume = interface.QueryInterface(IAudioEndpointVolume)
        current_volume = volume.GetMasterVolumeLevelScalar()
    finally:
        CoUninitialize()
    return current_volume

def set_volume(level):
    CoInitialize()
    try:
        devices = AudioUtilities.GetSpeakers()
        interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        volume = interface.QueryInterface(IAudioEndpointVolume)
        volume.SetMasterVolumeLevelScalar(level, None)
    finally:
        CoUninitialize()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_volume', methods=['GET'])
def get_volume_route():
    volume = get_volume()
    return jsonify({'volume': volume})

@app.route('/set_volume', methods=['POST'])
def set_volume_route():
    level = request.json.get('level')
    set_volume(level)
    return jsonify({'status': 'success'})

@app.route('/notify', methods=['POST'])
def notify():
    message = request.json.get('message')
    toaster.show_toast("Notification", message, duration=10)
    return jsonify({'status': 'success'})

@app.route('/installed_programs', methods=['GET'])
def installed_programs():
    programs = []
    for p in psutil.win_service_iter():
        programs.append(p.name())
    return jsonify({'programs': programs})

@app.route('/open_page', methods=['POST'])
def open_page():
    url = request.json.get('url')
    webbrowser.open(url)
    return jsonify({'status': 'success'})

if __name__ == '__main__':
    app.run(debug=True)
